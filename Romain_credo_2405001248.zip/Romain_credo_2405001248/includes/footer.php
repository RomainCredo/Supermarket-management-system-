</main>
<footer style="margin-top: 30px; padding: 20px; border-top: 1px solid #eee; background-color: skyblue; text-align: center;border-radius: 18px;">
    <div style="display: flex; justify-content: space-around; max-width: 900px; margin: 0 auto;">
        
        <div style="flex: 1; padding: 0 10px;">
            <p><strong>Contact & Location</strong></p>
            <p>📍 Musanze, Rwanda</p>
            <p>📞 0795567019 | 📧 credosupermarket@gmail.com</p>
        </div>

        <div style="flex: 1; padding: 0 10px;">
            <p><strong>Terms & Conditions (Summary)</strong></p>
            <div style="font-size: 12px; line-height: 1.4; color: #555; text-align: left; max-width: 300px; margin: 0 auto;">
                <p>Use of this system is governed by our Terms. All pricing and product information is subject to change. System access requires maintaining account confidentiality. Location: Musanze. Full terms apply.</p>
            </div>
            <p style="margin-top: 10px;">&copy; <?= date('Y') ?> Credo Supermarket</p>
        </div>
    </div>
</footer>

</body>
</html>