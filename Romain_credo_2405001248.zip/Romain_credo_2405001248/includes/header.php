<?php
if (session_status() === PHP_SESSION_NONE) session_start();
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Supermarket Management</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="/supermarket/style.css">
</head>
<body>
<div class="container my-4">
<header class="d-flex justify-content-between align-items-center p-3 bg-white rounded shadow-sm mb-3">
  <div class="d-flex align-items-center gap-3">
    <div class="badge bg-success rounded-circle p-3">SM</div>
    <div>
      <div class="h5 mb-0">Supermarket Manager</div>
      <small class="text-muted">Admin panel</small>
    </div>
  </div>
  <div>
    <?php if(isset($_SESSION['user'])): ?>
      <span class="me-2">Welcome, <?=htmlspecialchars($_SESSION['user']['fullname'] ?? $_SESSION['user']['username'])?></span>
      <a class="btn btn-sm btn-outline-secondary" href="../logout.php">Logout</a>
    <?php endif; ?>
  </div>
</header>
<nav class="mb-3">
  <a class="btn btn-sm btn-light me-1" href="../admin/dashboard.php">Dashboard</a>
  <a class="btn btn-sm btn-light me-1" href="../admin/products.php">Products</a>
  <a class="btn btn-sm btn-light me-1" href="../admin/customers.php">Customers</a>
  <a class="btn btn-sm btn-light me-1" href="../admin/orders.php">Orders</a>
  <a class="btn btn-sm btn-light" href="../admin/categories.php">Categories</a>
</nav>
<main>
