<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/db.php';
if (!isset($_SESSION['user'])) { 
  header('Location: /supermarket/login.php'); exit;
   }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action']==='add_cat') {
    $name = $_POST['name'] ?? '';
    if(trim($name)==='') { $err = 'Name required'; }
    else {
      $stmt = $mysqli->prepare('INSERT INTO categories (name) VALUES (?)');
      $stmt->bind_param('s', $name);
      $stmt->execute();
      header('Location: categories.php');
      exit;
    }
}
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $mysqli->query('DELETE FROM categories WHERE id=' . $id);
    header('Location: categories.php');
    exit;
}
$categories = $mysqli->query('SELECT * FROM categories')->fetch_all(MYSQLI_ASSOC);
?>
<div class="card p-3 mb-3">
  <h4>Categories</h4>
  <div class="row">
    <div class="col-lg-6">
      <table class="table table-striped"><thead><tr><th>Name</th><th>Action</th></tr></thead><tbody>
      <?php foreach($categories as $c): ?>
        <tr><td><?=htmlspecialchars($c['name'])?></td><td><a class="btn btn-sm btn-outline-primary" href="category_edit.php?id=<?=$c['id']?>">Edit</a> <a class="btn btn-sm btn-outline-danger" href="?delete=<?=$c['id']?>" onclick="return confirm('Delete?')">Delete</a></td></tr>
      <?php endforeach; ?>
      </tbody></table>
    </div>
    <div class="col-lg-6">
      <div class="card p-3">
        <h5>Add category</h5>
        <?php if(!empty($err)): ?><div class="alert alert-danger"><?=$err?></div><?php endif; ?>
        <form method="post" novalidate>
          <input type="hidden" name="action" value="add_cat">
          <div class="mb-2"><label class="form-label">Name<input name="name" required class="form-control"></label></div>
          <div class="d-flex justify-content-end"><button class="btn btn-primary">Add</button></div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>