<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/db.php';
if (!isset($_SESSION['user'])) { header('Location: /supermarket/login.php'); exit; }

// create order
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action']==='create_order') {
    $customer_id = $_POST['customer_id'] ?: null;
    $product_ids = $_POST['product_id'] ?? [];
    $qtys = $_POST['qty'] ?? [];
    $mysqli->begin_transaction();
    try {
        $order_date = date('Y-m-d');
        $total = 0;
        for($i=0;$i<count($product_ids);$i++){
            $pid = intval($product_ids[$i]); $q = intval($qtys[$i]);
            if($pid<=0 || $q<=0) continue;
            $p = $mysqli->query('SELECT price,stock FROM products WHERE id=' . $pid)->fetch_assoc();
            if(!$p) continue;
            if($p['stock'] < $q) throw new Exception('Insufficient stock for product ID ' . $pid);
            $total += $p['price'] * $q;
        }
        $status = 'Pending';
        $stmt = $mysqli->prepare('INSERT INTO orders (customer_id, order_date, status, total) VALUES (?,?,?,?)');
        $stmt->bind_param('issd', $customer_id, $order_date, $status, $total);
        $stmt->execute();
        $order_id = $mysqli->insert_id;
        for($i=0;$i<count($product_ids);$i++){
            $pid = intval($product_ids[$i]); $q = intval($qtys[$i]);
            if($pid<=0 || $q<=0) continue;
            $p = $mysqli->query('SELECT price,stock FROM products WHERE id=' . $pid)->fetch_assoc();
            $price = $p['price'];
            $stmt2 = $mysqli->prepare('INSERT INTO order_items (order_id, product_id, qty, price) VALUES (?,?,?,?)');
            $stmt2->bind_param('iiid', $order_id, $pid, $q, $price);
            $stmt2->execute();
            $mysqli->query('UPDATE products SET stock = stock - ' . $q . ' WHERE id=' . $pid);
        }
        $mysqli->commit();
        header('Location: orders.php');
        exit;
    } catch (Exception $e) {
        $mysqli->rollback();
        $error = $e->getMessage();
    }
}

// change status
if (isset($_GET['set_status'])) {
    $oid = intval($_GET['set_status']); $status = $_GET['status'] ?? 'Pending';
    $stmt = $mysqli->prepare('UPDATE orders SET status=? WHERE id=?'); $stmt->bind_param('si',$status,$oid); $stmt->execute();
    header('Location: orders.php'); exit;
}

$customers = $mysqli->query('SELECT * FROM customers')->fetch_all(MYSQLI_ASSOC);
$products = $mysqli->query('SELECT * FROM products')->fetch_all(MYSQLI_ASSOC);
$orders = $mysqli->query('SELECT o.*, c.name AS customer FROM orders o LEFT JOIN customers c ON o.customer_id=c.id ORDER BY o.id DESC')->fetch_all(MYSQLI_ASSOC);
?>
<div class="card p-3 mb-3">
  <h4>Orders</h4>
  <div class="row">
    <div class="col-lg-6">
      <div class="card p-3 mb-3">
        <h5>Create order</h5>
        <?php if(!empty($error)): ?><div class="alert alert-danger"><?=$error?></div><?php endif; ?>
        <form method="post" novalidate>
          <input type="hidden" name="action" value="create_order">
          <div class="mb-2"><label class="form-label">Customer<select name="customer_id" class="form-select"><option value="">Walk-in</option><?php foreach($customers as $c): ?><option value="<?=$c['id']?>"><?=htmlspecialchars($c['name'])?></option><?php endforeach; ?></select></label></div>
          <div id="lines">
            <div class="d-flex gap-2 mb-2">
              <select name="product_id[]" class="form-select"><?php foreach($products as $p): ?><option value="<?=$p['id']?>"><?=htmlspecialchars($p['name'])?> (Stock: <?=$p['stock']?>)</option><?php endforeach; ?></select>
              <input name="qty[]" type="number" value="1" min="1" class="form-control" style="width:100px">
            </div>
          </div>
          <div class="d-flex gap-2"><button type="button" class="btn btn-secondary" onclick="addLine()">Add line</button><button class="btn btn-success">Place Order</button></div>
        </form>
      </div>
      <script>
        function addLine(){
          var lines = document.getElementById('lines');
          var div = document.createElement('div'); div.className='d-flex gap-2 mb-2';
          div.innerHTML = `<?php ob_start(); ?><select name="product_id[]" class="form-select"><?php foreach($products as $p): ?><option value="<?=$p['id']?>"><?=htmlspecialchars($p['name'])?> (Stock: <?=$p['stock']?>)</option><?php endforeach; ?></select><input name="qty[]" type="number" value="1" min="1" class="form-control" style="width:100px"><button type="button" class="btn btn-outline-danger" onclick="this.parentNode.remove()">Remove</button><?php $s = ob_get_clean(); echo str_replace("
","",addslashes($s)); ?>`;
          lines.appendChild(div);
        }
      </script>
    </div>
    <div class="col-lg-6">
      <table class="table table-striped">
        <thead><tr><th>Order</th><th>Date</th><th>Customer</th><th>Total</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
        <?php foreach($orders as $o): ?>
          <tr>
            <td>#<?=$o['id']?></td>
            <td><?=htmlspecialchars($o['order_date'])?></td>
            <td><?=htmlspecialchars($o['customer'])?></td>
            <td><?=number_format($o['total'],2)?></td>
            <td><?=htmlspecialchars($o['status'])?></td>
            <td>
              <a class="btn btn-sm btn-outline-success" href="?set_status=<?=$o['id']?>&status=Completed">Complete</a>
              <a class="btn btn-sm btn-outline-primary" href="order_view.php?id=<?=$o['id']?>">View</a>
              <a class="btn btn-sm btn-outline-secondary" href="order_edit.php?id=<?=$o['id']?>">Edit</a>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>