<?php
session_start();
require_once '../config/db.php';
if(!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin'){
    header("Location: ../auth/login.php");
    exit();
}

$id = $_GET['id'];
$product = $mysqli->query("SELECT * FROM products WHERE id=$id")->fetch_assoc();
$categories = $mysqli->query("SELECT id, name FROM categories");

// Handle Update
if(isset($_POST['update'])){
    $name = $_POST['name'];
    $category_id = $_POST['category_id'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $stmt = $mysqli->prepare("UPDATE products SET name=?, category_id=?, price=?, stock=? WHERE id=?");
    $stmt->bind_param("sidii", $name, $category_id, $price, $stock, $id);
    $stmt->execute();
    header("Location: products.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="p-4">
<h2>Edit Product</h2>
<a href="products.php" class="btn btn-secondary mb-3">⬅ Back</a>
<form method="POST" class="row g-2">
    <div class="col-md-3">
        <input type="text" name="name" value="<?= htmlspecialchars($product['name']) ?>" class="form-control" required>
    </div>
    <div class="col-md-3">
        <select name="category_id" class="form-select" required>
            <?php while($c = $categories->fetch_assoc()): ?>
                <option value="<?= $c['id'] ?>" <?= $c['id']==$product['category_id']?'selected':'' ?>><?= htmlspecialchars($c['name']) ?></option>
            <?php endwhile; ?>
        </select>
    </div>
    <div class="col-md-2">
        <input type="text"name="price" value="<?= $product['price'] ?>" class="form-control" required>
    </div>
    <div class="col-md-2">
        <input type="number" name="stock" value="<?= $product['stock'] ?>" class="form-control" required>
    </div>
    <div class="col-md-2">
        <button type="submit" name="update" class="btn btn-primary w-100">Update Product</button>
    </div>
</form>
</body>
</html>
