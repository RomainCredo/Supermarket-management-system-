<?php
session_start();
require_once '../config/db.php';
if(!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin'){
    header("Location: ../auth/login.php");
    exit();
}

$id = $_GET['id'];
$user = $mysqli->query("SELECT * FROM users WHERE id=$id")->fetch_assoc();

if(isset($_POST['update'])){
    $username = $_POST['username'];
    $fullname = $_POST['fullname'];
    $password = $_POST['password'];
    $role = $_POST['role'];
    $stmt = $mysqli->prepare("UPDATE users SET username=?, fullname=?, password=?, role=? WHERE id=?");
    $stmt->bind_param("ssssi", $username, $fullname, $password, $role, $id);
    $stmt->execute();
    header("Location: users.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit User</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="p-4">
<h2>Edit User</h2>
<a href="users.php" class="btn btn-secondary mb-3">⬅ Back</a>
<form method="POST">
    <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>
    <input type="text" name="fullname" value="<?= htmlspecialchars($user['fullname']) ?>" required>
    <input type="password" name="password" value="<?= htmlspecialchars($user['password']) ?>" required>
    <select name="role">
        <option value="user" <?= $user['role']=='user'?'selected':'' ?>>User</option>
        <option value="admin" <?= $user['role']=='admin'?'selected':'' ?>>Admin</option>
    </select>
    <button type="submit" name="update" class="btn btn-primary">Update User</button>
</form>
</body>
</html>
