<?php
session_start();
require_once '../config/db.php';
if(!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin'){
    header("Location: ../auth/login.php");
    exit();
}

// Handle Add User
if(isset($_POST['add'])){
    $username = $_POST['username'];
    $password = $_POST['password'];
    $fullname = $_POST['fullname'];
    $role = $_POST['role'];
    $stmt = $mysqli->prepare("INSERT INTO users (username, password, fullname, role) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $username, $password, $fullname, $role);
    $stmt->execute();
}

// Handle Delete User
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    $mysqli->query("DELETE FROM users WHERE id=$id");
}

// Fetch users
$users = $mysqli->query("SELECT id, username, fullname, role FROM users");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Users</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="p-4">
<h2>Users Management</h2>
<a href="dashboard.php" class="btn btn-secondary mb-3">⬅ Back</a>

<!-- Add User Form -->
<form method="POST" class="mb-3">
    <input type="text" name="username" placeholder="Username" required>
    <input type="text" name="fullname" placeholder="Full Name" required>
    <input type="password" name="password" placeholder="Password" required>
    <select name="role">
        <option value="user">User</option>
        <option value="admin">Admin</option>
    </select>
    <button type="submit" name="add" class="btn btn-success">Add User</button>
</form>

<!-- Users Table -->
<table class="table table-bordered table-custom">
<thead>
<tr>
    <th>ID</th><th>Username</th><th>Full Name</th><th>Role</th><th>Actions</th>
</tr>
</thead>
<tbody>
<?php while($row = $users->fetch_assoc()): ?>
<tr>
    <td><?= $row['id'] ?></td>
    <td><?= htmlspecialchars($row['username']) ?></td>
    <td><?= htmlspecialchars($row['fullname']) ?></td>
    <td><?= $row['role'] ?></td>
    <td>
        <a href="users_edit.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
        <a href="?delete=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete user?')">Delete</a>
    </td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</body>
</html>
