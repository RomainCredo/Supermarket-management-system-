<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/db.php';
if (!isset($_SESSION['user'])) { header('Location: /supermarket/login.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action']==='add_customer') {
    $name = $_POST['name'] ?? ''; $phone = $_POST['phone'] ?? ''; $email = $_POST['email'] ?? '';
    if(trim($name)==='') { $err = 'Name required'; }
    else {
      $stmt = $mysqli->prepare('INSERT INTO customers (name, phone, email) VALUES (?,?,?)');
      $stmt->bind_param('sss', $name, $phone, $email);
      $stmt->execute();
      header('Location: customers.php');
      exit;
    }
}
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $mysqli->query('DELETE FROM customers WHERE id=' . $id);
    header('Location: customers.php');
    exit;
}
$customers = $mysqli->query('SELECT * FROM customers')->fetch_all(MYSQLI_ASSOC);
?>
<div class="card p-3 mb-3">
  <h4>Customers</h4>
  <div class="row">
    <div class="col-lg-8">
      <table class="table table-striped">
        <thead><tr><th>Name</th><th>Phone</th><th>Email</th><th>Action</th></tr></thead>
        <tbody>
        <?php foreach($customers as $c): ?>
          <tr>
            <td><?=htmlspecialchars($c['name'])?></td>
            <td><?=htmlspecialchars($c['phone'])?></td>
            <td><?=htmlspecialchars($c['email'])?></td>
            <td><a class="btn btn-sm btn-outline-primary" href="customer_edit.php?id=<?=$c['id']?>">Edit</a> <a class="btn btn-sm btn-outline-danger" href="?delete=<?=$c['id']?>" onclick="return confirm('Delete customer?')">Delete</a></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="col-lg-4">
      <div class="card p-3">
        <h5>Add customer</h5>
        <?php if(!empty($err)): ?><div class="alert alert-danger"><?=$err?></div><?php endif; ?>
        <form method="post" novalidate>
          <input type="hidden" name="action" value="add_customer">
          <div class="mb-2"><label class="form-label">Name<input name="name" required class="form-control"></label></div>
          <div class="mb-2"><label class="form-label">Phone<input name="phone" class="form-control"></label></div>
          <div class="mb-2"><label class="form-label">Email<input name="email" type="email" class="form-control"></label></div>
          <div class="d-flex justify-content-end"><button class="btn btn-primary">Add</button></div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>