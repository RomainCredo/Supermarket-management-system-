<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/db.php';
if (!isset($_SESSION['user'])) { header('Location: /supermarket/login.php'); exit; }

$id = intval($_GET['id'] ?? 0); if(!$id) { header('Location: categories.php'); exit; }
$stmt = $mysqli->prepare('SELECT * FROM categories WHERE id=? LIMIT 1'); $stmt->bind_param('i',$id); $stmt->execute();
$cat = $stmt->get_result()->fetch_assoc(); if(!$cat) { header('Location: categories.php'); exit; }

$msg='';
if($_SERVER['REQUEST_METHOD']==='POST') {
    $name = $_POST['name'] ?? '';
    if(!trim($name)) $msg='Name is required';
    else { $stmt = $mysqli->prepare('UPDATE categories SET name=? WHERE id=?'); $stmt->bind_param('si',$name,$id); $stmt->execute(); header('Location: categories.php'); exit; }
}
?>
<div class="card p-3 mb-3">
  <h4>Edit category</h4>
  <?php if($msg): ?><div class="alert alert-danger"><?=$msg?></div><?php endif; ?>
  <form method="post" novalidate>
    <div class="mb-2"><label class="form-label">Name<input name="name" required class="form-control" value="<?=htmlspecialchars($cat['name'])?>"></label></div>
    <div class="d-flex gap-2"><button class="btn btn-primary">Save</button> <a class="btn btn-secondary" href="categories.php">Cancel</a></div>
  </form>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>