<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/db.php';
if (!isset($_SESSION['user'])) { header('Location: /supermarket/login.php'); exit; }

$id = intval($_GET['id'] ?? 0);
if(!$id) { header('Location: orders.php'); exit; }

$order = $mysqli->query('SELECT o.*, c.name AS customer FROM orders o LEFT JOIN customers c ON o.customer_id=c.id WHERE o.id=' . $id)->fetch_assoc();
if(!$order) { header('Location: orders.php'); exit; }
$items = $mysqli->query('SELECT oi.*, p.name, p.stock, p.id AS pid FROM order_items oi LEFT JOIN products p ON oi.product_id=p.id WHERE oi.order_id=' . $id)->fetch_all(MYSQLI_ASSOC);

$msg='';
if($_SERVER['REQUEST_METHOD']==='POST') {
    $status = $_POST['status'] ?? $order['status'];
    $qtys = $_POST['qty'] ?? [];
    $pids = $_POST['product_id'] ?? [];
    $mysqli->begin_transaction();
    try {
        for($i=0;$i<count($pids);$i++){
            $pid = intval($pids[$i]); $newq = intval($qtys[$i]);
            $row = $mysqli->query('SELECT id, qty FROM order_items WHERE order_id=' . $id . ' AND product_id=' . $pid)->fetch_assoc();
            if($row){
                $oldq = intval($row['qty']);
                $diff = $newq - $oldq;
                if($diff !== 0){
                    if($diff > 0){
                        $p = $mysqli->query('SELECT stock FROM products WHERE id=' . $pid)->fetch_assoc();
                        if($p['stock'] < $diff) throw new Exception('Insufficient stock for product ID ' . $pid);
                        $mysqli->query('UPDATE products SET stock = stock - ' . $diff . ' WHERE id=' . $pid);
                    } else {
                        $mysqli->query('UPDATE products SET stock = stock + ' . abs($diff) . ' WHERE id=' . $pid);
                    }
                    $mysqli->query('UPDATE order_items SET qty=' . $newq . ' WHERE id=' . intval($row['id']));
                }
            }
        }
        $stmt = $mysqli->prepare('UPDATE orders SET status=? WHERE id=?'); $stmt->bind_param('si',$status,$id); $stmt->execute();
        $mysqli->commit();
        header('Location: orders.php');
        exit;
    } catch(Exception $e){
        $mysqli->rollback();
        $msg = $e->getMessage();
    }
}
?>
<div class="card p-3 mb-3">
  <h4>Edit Order #<?=$id?></h4>
  <?php if($msg): ?><div class="alert alert-danger"><?=$msg?></div><?php endif; ?>
  <div class="small mb-2">Customer: <?=htmlspecialchars($order['customer'])?> — Date: <?=$order['order_date']?></div>
  <form method="post" novalidate>
    <div class="mb-2"><label class="form-label">Status<select name="status" class="form-select"><option value="Pending" <?=($order['status']=='Pending')?'selected':''?>>Pending</option><option value="Completed" <?=($order['status']=='Completed')?'selected':''?>>Completed</option><option value="Cancelled" <?=($order['status']=='Cancelled')?'selected':''?>>Cancelled</option></select></label></div>
    <table class="table"><thead><tr><th>Product</th><th>Available</th><th>Qty</th></tr></thead><tbody>
      <?php foreach($items as $it): ?>
        <tr>
          <td><?=htmlspecialchars($it['name'])?></td>
          <td><?=$it['stock']?></td>
          <td>
            <input type="hidden" name="product_id[]" value="<?=$it['product_id']?>">
            <input name="qty[]" type="number" value="<?=$it['qty']?>" min="0" class="form-control" style="width:110px">
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody></table>
    <div class="d-flex gap-2"><button class="btn btn-primary">Save</button> <a class="btn btn-secondary" href="orders.php">Cancel</a></div>
  </form>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>