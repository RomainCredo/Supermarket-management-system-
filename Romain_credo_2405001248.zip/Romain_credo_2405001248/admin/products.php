<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/db.php';
if (!isset($_SESSION['user'])) { header('Location: /supermarket/login.php'); exit; }

// Handle add product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_product') {
    $name = $_POST['name'] ?? ''; $sku = $_POST['sku'] ?? ''; $price = $_POST['price'] ?? 0; $stock = $_POST['stock'] ?? 0; $cat = $_POST['category_id'] ?: null;
    if(trim($name)==='') { $err = 'Name required'; }
    else {
      $stmt = $mysqli->prepare('INSERT INTO products (name, sku, price, stock, category_id) VALUES (?,?,?,?,?)');
      $stmt->bind_param('ssdii', $name, $sku, $price, $stock, $cat);
      $stmt->execute();
      header('Location: products.php');
      exit;
    }
}

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $mysqli->query('DELETE FROM products WHERE id=' . $id);
    header('Location: products.php');
    exit;
}

$categories = $mysqli->query('SELECT * FROM categories')->fetch_all(MYSQLI_ASSOC);
$products = $mysqli->query('SELECT p.*, c.name AS category FROM products p LEFT JOIN categories c ON p.category_id=c.id')->fetch_all(MYSQLI_ASSOC);
?>
<div class="card p-3 mb-3">
  <h4>Products</h4>
  <div class="row">
    <div class="col-lg-8">
      <table class="table table-striped">
        <thead><tr><th>Name</th><th>SKU</th><th>Category</th><th>Price</th><th>Stock</th><th>Actions</th></tr></thead>
        <tbody>
        <?php foreach($products as $p): ?>
          <tr>
            <td><?=htmlspecialchars($p['name'])?></td>
            <td><?=htmlspecialchars($p['sku'])?></td>
            <td><?=htmlspecialchars($p['category'])?></td>
            <td><?=number_format($p['price'],2)?></td>
            <td><?=intval($p['stock'])?></td>
            <td><a class="btn btn-sm btn-outline-primary" href="product_edit.php?id=<?=$p['id']?>">Edit</a> <a class="btn btn-sm btn-outline-danger" href="?delete=<?=$p['id']?>" onclick="return confirm('Delete product?')">Delete</a></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="col-lg-4">
      <div class="card p-3">
        <h5>Add product</h5>
        <?php if(!empty($err)): ?><div class="alert alert-danger"><?=$err?></div><?php endif; ?>
        <form method="post" novalidate>
          <input type="hidden" name="action" value="add_product">
          <div class="mb-2"><label class="form-label">Name<input name="name" required class="form-control"></label></div>
          <div class="mb-2"><label class="form-label">SKU<input name="sku" class="form-control"></label></div>
          <div class="mb-2"><label class="form-label">Price<input name="price" type="text" class="form-control"></label></div>
          <div class="mb-2"><label class="form-label">Stock<input name="stock" type="number" value="0" class="form-control"></label></div>
          <div class="mb-2"><label class="form-label">Category<select name="category_id" class="form-select"><option value="">-- none --</option><?php foreach($categories as $c): ?><option value="<?=$c['id']?>"><?=htmlspecialchars($c['name'])?></option><?php endforeach; ?></select></label></div>
          <div class="d-flex justify-content-end"><button class="btn btn-success">Add</button></div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>