<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/db.php';
if (!isset($_SESSION['user'])) { header('Location: /supermarket/login.php'); exit; }
$id=intval($_GET['id']??0);
if(!$id){header('Location: customers.php');exit;}
$stmt=$mysqli->prepare('SELECT * FROM customers WHERE id=?');$stmt->bind_param('i',$id);$stmt->execute();
$cust=$stmt->get_result()->fetch_assoc();
if(!$cust){header('Location: customers.php');exit;}
$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
$name=$_POST['name']??'';$phone=$_POST['phone']??'';$email=$_POST['email']??'';
if(!trim($name)){$msg='Name required';}else{
$stmt=$mysqli->prepare('UPDATE customers SET name=?,phone=?,email=? WHERE id=?');
$stmt->bind_param('sssi',$name,$phone,$email,$id);$stmt->execute();header('Location: customers.php');exit;}
}
?><div class="card"><h2>Edit Customer</h2>
<?php if($msg):?><div class="alert"><?=$msg?></div><?php endif;?>
<form method="post"><label>Name<input name="name" value="<?=htmlspecialchars($cust['name'])?>"></label>
<label>Phone<input name="phone" value="<?=htmlspecialchars($cust['phone'])?>"></label>
<label>Email<input name="email" value="<?=htmlspecialchars($cust['email'])?>"></label>
<button>Save</button><a href="customers.php">Cancel</a></form></div><?php require_once __DIR__ . '/../includes/footer.php'; ?>