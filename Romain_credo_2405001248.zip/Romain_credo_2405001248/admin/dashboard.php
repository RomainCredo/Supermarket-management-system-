<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: ../index.php');
    exit;
}
if ($_SESSION['user']['role'] !== 'admin') {
    header('Location: ../admin/dashboard.php');
    exit;
}
$fullname = $_SESSION['user']['fullname'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard - Supermarket</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background: #f4f6f9; }
    .sidebar { height: 100vh; background-color: #185a9d; color: white; padding-top: 20px; position: fixed; width: 220px; }
    .sidebar a { display: block; color: white; text-decoration: none; padding: 12px 20px; }
    .sidebar a:hover { background: rgba(255,255,255,0.1); }
    .content { margin-left: 230px; padding: 30px; }
  </style>
</head>
<body>

<div class="sidebar">
  <h4 class="text-center">🛒 Admin Panel</h4>
  <hr>
  <a href="dashboard.php">🏠 Dashboard</a>
  <a href="products.php">📦 Products</a>
  <a href="orders.php">🧾 Orders</a>
  <a href="customers.php">🧍 Customers</a>
  <a href="categories.php">📂 Categories</a>
  <a href="users.php">📂 Add User</a>
  <a href="../logout.php" class="text-danger">🚪 Logout</a>
</div>

<div class="content">
  <h2>Welcome, <?= htmlspecialchars($fullname) ?> 👋</h2>
  <p>Select a section from the left to manage supermarket data.</p>
</div>

</body>
</html>
