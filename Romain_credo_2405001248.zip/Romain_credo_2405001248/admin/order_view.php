<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/db.php';
if (!isset($_SESSION['user'])) { header('Location: /supermarket/login.php'); exit; }
$id = intval($_GET['id'] ?? 0);
$order = $mysqli->query('SELECT o.*, c.name AS customer FROM orders o LEFT JOIN customers c ON o.customer_id=c.id WHERE o.id=' . $id)->fetch_assoc();
$items = $mysqli->query('SELECT oi.*, p.name FROM order_items oi LEFT JOIN products p ON oi.product_id=p.id WHERE oi.order_id=' . $id)->fetch_all(MYSQLI_ASSOC);
?>
<div class="card p-3 mb-3">
  <h4>Order #<?=$id?></h4>
  <?php if($order): ?>
    <div class="small mb-2">Customer: <?=htmlspecialchars($order['customer'])?> — Date: <?=$order['order_date']?></div>
    <table class="table"><thead><tr><th>Product</th><th>Qty</th><th>Price</th></tr></thead><tbody>
      <?php foreach($items as $it): ?>
        <tr><td><?=htmlspecialchars($it['name'])?></td><td><?=$it['qty']?></td><td><?=number_format($it['price'],2)?></td></tr>
      <?php endforeach; ?>
    </tbody></table>
  <?php else: ?>
    <div class="alert alert-warning">Order not found.</div>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>