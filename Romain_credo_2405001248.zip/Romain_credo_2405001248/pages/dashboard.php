<?php
session_start();

// Access control: only logged-in users
if (!isset($_SESSION['user'])) {
    header('Location: ../index.php');
    exit;
}

if ($_SESSION['user']['role'] === 'admin') {
    header('Location: ../pages/dashboard.php');
    exit;
}

$fullname = $_SESSION['user']['fullname'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Dashboard - Supermarket</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(to right, #43cea2, #185a9d);
      color: #fff;
      height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
    }
    .dashboard-box {
      background: rgba(255,255,255,0.15);
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 0 10px rgba(0,0,0,0.3);
      max-width: 500px;
    }
  </style>
</head>
<body>

<div class="dashboard-box">
  <h2>Welcome, <?= htmlspecialchars($fullname) ?> 👋</h2>
  <p>This is your <strong>User Dashboard</strong>.</p>

  <div class="mt-4">
    <a href="products.php" class="btn btn-light mb-2 w-100">🛍 View Products</a>
    <a href="orders.php" class="btn btn-light mb-2 w-100">🧾 View Orders</a>
    <a href="history.php" class="btn btn-light mb-2 w-100">📜 Purchase History</a>
    <a href="../logout.php" class="btn btn-danger w-100">🚪 Logout</a>
  </div>
</div>

</body>
</html>
